from distutils.core import setup

setup(name="opresearch",
        packages=["opresearch"],
        version="0.0.1",
        author="Rene Garcia",
        author_email="garciamx@gmail.com",
        url="https://github.com/ixxra/opresearch",
        description="",
        long_description="",
        classifiers=[
            "Programming Language :: Python",
            "License :: OSI Approved :: BSD License",
            "Operating System :: OS Independent",
            "Development Status :: 1 - Planning",
            "Environment :: Console",
            "Intended Audience :: Education",
            "Topic :: Education"
            ])
